// Configura estos dos valores después de crear tu proyecto en Supabase.
// La clave anon/publishable es pública. NUNCA pongas la service_role key aquí.
window.MUSEO_CONFIG = {
  supabaseUrl: "",
  supabaseAnonKey: ""
};
