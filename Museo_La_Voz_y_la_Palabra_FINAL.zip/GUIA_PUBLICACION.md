# LA VOZ Y LA PALABRA — Guía para publicar y editar

**Equipo:** Gonzalo Martínez, Isaac Elizondo y Pato Abrego. **Entrega:** 23 de noviembre de 2026.

## 1. Abrir y revisar ahora

Abre `index.html` en tu navegador. Recorre las seis puertas. La versión pública funciona sin base de datos y tiene el contenido literario, los guiones y las conexiones AP. Los botones de lectura automática utilizan la voz del navegador. El audio subido directamente desde una sala es temporal y no se comparte con otras personas.

## 2. Publicar la página gratis con GitHub Pages

1. Crea una cuenta en https://github.com/ y un repositorio **público** llamado `museo-literario`.
2. Sube **todos los archivos y carpetas de este ZIP**, no el ZIP mismo. `index.html`, `config.js` y la carpeta `admin` deben quedar en la raíz.
3. En el repositorio abre **Settings > Pages**. En **Build and deployment**, selecciona **Deploy from a branch**, rama `main`, carpeta `/(root)` y guarda.
4. Espera a que aparezca **Visit site**. El enlace será parecido a `https://USUARIO.github.io/museo-literario/` (el enlace exacto lo proporciona GitHub).
5. El museo público ya funciona. Para que el panel `/admin` guarde cambios en línea, sigue la sección 3.

## 3. Activar la edición compartida y las grabaciones permanentes

**Se requiere una cuenta Supabase y configurar un proyecto. No está conectado de fábrica.**

1. Crea un proyecto en https://supabase.com/.
2. En **SQL Editor**, ejecuta `supabase_schema.sql`. Luego ejecuta `seed_rooms.sql` para cargar las seis salas editables.
3. En **Project Settings > API**, copia **Project URL** y la clave **anon/publishable** (NO la clave `service_role` ni ningún secreto).
4. Edita `config.js` y pega ambos valores en `supabaseUrl` y `supabaseAnonKey`. Sube el archivo actualizado a GitHub.
5. En **Authentication > Users**, crea cuentas para Gonzalo, Isaac y Pato mediante el flujo de invitación o alta de usuarios que permita tu proyecto. Cada uno debe usar su propio correo y contraseña. No compartan contraseñas.
6. Copia el UUID de cada cuenta desde Authentication > Users y ejecuta estas sentencias en SQL Editor, sustituyendo los UUID:

```sql
insert into public.museum_members(user_id,role) values ('UUID_GONZALO','admin');
insert into public.museum_members(user_id,role) values ('UUID_ISAAC','editor');
insert into public.museum_members(user_id,role) values ('UUID_PATO','editor');
```

7. Abre la URL pública seguida de `/admin/`, por ejemplo `https://USUARIO.github.io/museo-literario/admin/`. Inicia sesión, elige una sala, modifica un texto, pulsa **Guardar borrador**, después **Publicar cambios** y recarga el museo público.
8. Para subir un audio, usa el control **Subir audio** dentro de la sala en el administrador y después **Publicar cambios**. El audio se mostrará en la sala pública.

### Seguridad y límites

- El sitio público no requiere cuenta; el administrador sí.
- Las políticas RLS limitan la edición a usuarios registrados en `museum_members`.
- La vista pública `museum_published` expone únicamente contenido publicado, no borradores.
- Los archivos multimedia publicados se almacenan en buckets públicos. No suban datos privados ni fotos personales sin permiso.
- Las cuentas de colaboradores se autorizan desde Supabase SQL Editor. El dashboard no ofrece invitaciones automáticas ni historial de versiones completo.
- Las imágenes y audios subidos se mantienen en Supabase; los cambios de texto se guardan en la base de datos.
- Los botones de edición solo funcionarán después de completar esta configuración.

## 4. Antes de entregar a la maestra

- Grabar **seis análisis** (Gonzalo: salas 1 y 4; Isaac: 2 y 3; Pato: 5 y 6).
- Subir los audios desde `/admin/` y publicarlos.
- Revisar las fuentes académicas y la edición de clase. Las referencias de la web son portales institucionales de consulta, no referencias bibliográficas completas a ediciones específicas.
- Confirmar que los contenidos correspondan a lo que vio el grupo en clase.
- Abrir el enlace público en una ventana privada y desde un celular para comprobar que funciona.
- Compartir **solo el enlace público** con la maestra, no contraseñas.

## 5. Qué incluye el proyecto

- `index.html`: museo público con seis salas y guiones.
- `admin/index.html` y `admin/admin.js`: panel de edición conectado a Supabase.
- `config.js`: configuración de conexión (vacía inicialmente).
- `supabase_schema.sql`: tablas, seguridad y almacenamiento.
- `seed_rooms.sql`: contenido inicial editable de las seis salas.
- `GUIA_PUBLICACION.md`: esta guía.

Este paquete es una implementación web funcional en modo local y preparada para conexión en línea. **No se ha desplegado en una cuenta pública ni configurado Supabase automáticamente.**
