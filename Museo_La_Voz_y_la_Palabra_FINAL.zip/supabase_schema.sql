-- Ejecutar en Supabase > SQL Editor, en un proyecto nuevo.
create table if not exists public.museum_members (
  user_id uuid primary key references auth.users(id) on delete cascade,
  role text not null check (role in ('admin','editor')),
  created_at timestamptz not null default now()
);
create table if not exists public.museum_rooms (
  room_id text primary key check (room_id in ('lucanor','soneto','sorjuana','quijote','rima','vision')),
  draft_content jsonb not null default '{}'::jsonb,
  published_content jsonb not null default '{}'::jsonb,
  audio_url text,
  image_url text,
  updated_at timestamptz not null default now(),
  published_at timestamptz
);
alter table public.museum_members enable row level security;
alter table public.museum_rooms enable row level security;
-- Users can only read their own membership, to avoid recursion in policies.
create policy "read own membership" on public.museum_members for select to authenticated using (user_id=auth.uid());
-- Membership management occurs via Supabase dashboard / SQL editor (not publicly writable).
create policy "read published rooms" on public.museum_rooms for select to anon,authenticated using (true);
create policy "edit rooms as member" on public.museum_rooms for insert to authenticated with check (exists(select 1 from public.museum_members where user_id=auth.uid()));
create policy "update rooms as member" on public.museum_rooms for update to authenticated using (exists(select 1 from public.museum_members where user_id=auth.uid())) with check (exists(select 1 from public.museum_members where user_id=auth.uid()));
-- IMPORTANT: public read policy above exposes drafts. Fix with separate published-only view.
-- Drop public read policy and use secure published view instead.
drop policy "read published rooms" on public.museum_rooms;
create policy "members read rooms" on public.museum_rooms for select to authenticated using (exists(select 1 from public.museum_members where user_id=auth.uid()));
create or replace view public.museum_published with (security_invoker=false) as
select room_id,published_content,audio_url,image_url from public.museum_rooms where published_at is not null;
revoke all on public.museum_rooms from anon;
grant select on public.museum_published to anon,authenticated;
insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types)
values ('museum-audio','museum-audio',true,20971520,array['audio/mpeg','audio/mp4','audio/x-m4a','audio/wav','audio/ogg'])
on conflict (id) do nothing;
create policy "members upload audio" on storage.objects for insert to authenticated with check (bucket_id='museum-audio' and exists(select 1 from public.museum_members where user_id=auth.uid()));
-- In Supabase Authentication, create each team member as a user.
-- Copy their auth.users UUID and run, one at a time:
-- insert into public.museum_members(user_id,role) values ('UUID_DE_GONZALO','admin');
-- insert into public.museum_members(user_id,role) values ('UUID_DE_ISAAC','editor');
-- insert into public.museum_members(user_id,role) values ('UUID_DE_PATO','editor');

insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types)
values ('museum-images','museum-images',true,5242880,array['image/jpeg','image/png','image/webp'])
on conflict (id) do nothing;
create policy "members upload images" on storage.objects for insert to authenticated with check (bucket_id='museum-images' and exists(select 1 from public.museum_members where user_id=auth.uid()));
